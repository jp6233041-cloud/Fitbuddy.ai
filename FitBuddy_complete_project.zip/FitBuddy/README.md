# FitBuddy – AI Fitness Plan Generator

FitBuddy is a FastAPI + Jinja2 + SQLite web application that generates a structured 7-day wellness plan and a concise nutrition/recovery tip with Google Gemini. Users can submit feedback to regenerate their plan, and an admin dashboard can inspect stored users and plans.

## Architecture

- Frontend: HTML, CSS, Jinja2
- Backend: FastAPI
- AI: Google Gemini via the modern `google-genai` Python SDK
- Database: SQLite + SQLAlchemy
- Tests: pytest + FastAPI TestClient
- Configuration: `.env`

The original project documentation describes Gemini 1.5 Pro + Gemini Flash. Those model names are legacy relative to current Gemini API documentation, so this implementation uses configurable current model IDs. Change them in `.env` if your Google account exposes a different model.

## Quick start – Windows

```powershell
py -3 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
copy .env.example .env
```

Edit `.env` and put your Gemini API key into `GEMINI_API_KEY`.

Run:

```powershell
uvicorn app.main:app --reload
```

Open:
- http://127.0.0.1:8000
- http://127.0.0.1:8000/docs

Admin:
- http://127.0.0.1:8000/view-all-users
- use the `ADMIN_PASSWORD` from `.env`

## macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```

## Test

```bash
pytest -q
```

## Important safety note

FitBuddy is a wellness-planning demo, not a medical device. The app deliberately avoids calorie restriction, fasting, supplement prescriptions, extreme exercise instructions, and appearance-based targets. Users should stop activity if they experience pain and seek qualified guidance for individualized needs.

## Production notes

Before public deployment:
1. Replace the simple admin-password query parameter flow with proper authentication and sessions.
2. Use PostgreSQL or another production database.
3. Add CSRF protection, rate limiting, structured logging, and secret management.
4. Never commit `.env`.
5. Pin dependency versions after testing your deployment environment.
