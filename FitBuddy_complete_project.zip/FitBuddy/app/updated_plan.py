import json
from google import genai
from google.genai import types
from .config import get_settings

settings = get_settings()

def update_workout_plan(original_plan: str, feedback: str, user) -> str:
    if not settings.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY is not configured.")
    client = genai.Client(api_key=settings.gemini_api_key)
    prompt = f"""
Update this existing 7-day wellness plan using the user's feedback.

User: {user.username}, age {user.age}, goal {user.goal}, intensity {user.intensity}
Feedback: {feedback}

Original plan:
{original_plan}

Return valid JSON with exactly:
{{
  "days": [...7 day objects...],
  "safety_note": "..."
}}

Keep the same safe structure as the original plan. Make reasonable changes,
preserve useful parts, include recovery, and never introduce extreme exercise,
calorie restriction, fasting, supplements, or unsafe instructions. For minors,
keep the plan age-appropriate.
"""
    response = client.models.generate_content(
        model=settings.gemini_workout_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            temperature=0.5,
            response_mime_type="application/json",
            max_output_tokens=6000,
        ),
    )
    text = response.text or ""
    try:
        data = json.loads(text)
        if not isinstance(data.get("days"), list) or len(data["days"]) != 7:
            raise ValueError("Updated plan must contain exactly 7 days.")
        return json.dumps(data, indent=2, ensure_ascii=False)
    except (json.JSONDecodeError, ValueError, TypeError) as exc:
        raise RuntimeError(f"Gemini returned an invalid updated plan: {exc}") from exc
