from sqlalchemy import select
from sqlalchemy.orm import Session
from .database import User, Plan

def get_user(db: Session, user_id: str):
    return db.scalar(select(User).where(User.user_id == user_id))

def save_user(db: Session, data) -> User:
    user = get_user(db, data.user_id)
    if user:
        user.username = data.username
        user.age = data.age
        user.weight = data.weight
        user.goal = data.goal
        user.intensity = data.intensity
    else:
        user = User(
            user_id=data.user_id, username=data.username, age=data.age,
            weight=data.weight, goal=data.goal, intensity=data.intensity
        )
        db.add(user)
        db.flush()
    return user

def save_plan(db: Session, user: User, original_plan: str, nutrition_tip: str) -> Plan:
    plan = Plan(user_id=user.id, original_plan=original_plan, nutrition_tip=nutrition_tip)
    db.add(plan)
    db.commit()
    db.refresh(plan)
    return plan

def get_latest_plan(db: Session, user: User):
    return db.scalar(
        select(Plan).where(Plan.user_id == user.id).order_by(Plan.created_at.desc())
    )

def update_plan(db: Session, plan: Plan, updated_plan: str, feedback: str) -> Plan:
    plan.updated_plan = updated_plan
    plan.last_feedback = feedback
    db.commit()
    db.refresh(plan)
    return plan

def get_all_users(db: Session):
    return db.scalars(select(User).order_by(User.created_at.desc())).all()

def delete_user(db: Session, user: User) -> None:
    db.delete(user)
    db.commit()
