import json
from google import genai
from google.genai import types
from .config import get_settings

settings = get_settings()

def _client() -> genai.Client:
    if not settings.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY is not configured.")
    return genai.Client(api_key=settings.gemini_api_key)

def generate_workout_gemini(user) -> str:
    prompt = f"""
Create a safe, age-appropriate 7-day wellness and fitness plan.
User:
- Name: {user.username}
- Age: {user.age}
- Weight (kg): {user.weight}
- Goal: {user.goal}
- Preferred intensity: {user.intensity}

Return valid JSON only with this exact top-level shape:
{{
  "days": [
    {{
      "day": "Day 1",
      "focus": "...",
      "warmup": ["..."],
      "workout": [
        {{"exercise": "...", "sets": 0, "reps_or_duration": "...", "rest": "..."}}
      ],
      "cooldown": ["..."],
      "note": "..."
    }}
  ],
  "safety_note": "..."
}}

Requirements:
- Exactly 7 days.
- Include rest/recovery where appropriate.
- Keep recommendations general wellness guidance, not diagnosis or treatment.
- Do not prescribe calorie restriction, fasting, supplements, or extreme exercise.
- For users under 18, prioritize age-appropriate activity, recovery, enjoyment, and adult/professional guidance when needed.
- Avoid body-shaming language and appearance-based targets.
- Use clear exercise names and simple instructions.
"""
    response = _client().models.generate_content(
        model=settings.gemini_workout_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            temperature=0.5,
            response_mime_type="application/json",
            max_output_tokens=6000,
        ),
    )
    text = response.text or ""
    try:
        data = json.loads(text)
        if not isinstance(data.get("days"), list) or len(data["days"]) != 7:
            raise ValueError("Gemini returned an invalid 7-day plan.")
        return json.dumps(data, indent=2, ensure_ascii=False)
    except (json.JSONDecodeError, ValueError, TypeError) as exc:
        raise RuntimeError(f"Gemini returned an invalid plan format: {exc}") from exc
