import json
from pathlib import Path
from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from .config import get_settings
from .database import get_db
from .schemas import UserInput
from .crud import get_user, save_user, save_plan, get_latest_plan, update_plan, get_all_users, delete_user
from .gemini_generator import generate_workout_gemini
from .gemini_flash_generator import generate_nutrition_tip_with_flash
from .updated_plan import update_workout_plan

BASE_DIR = Path(__file__).resolve().parent.parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))
router = APIRouter()

def plan_for_template(plan_text: str):
    try:
        return json.loads(plan_text)
    except Exception:
        return {"raw": plan_text}

@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@router.post("/generate-workout", response_class=HTMLResponse)
def generate_workout(
    request: Request,
    username: str = Form(...),
    user_id: str = Form(...),
    age: int = Form(...),
    weight: float = Form(...),
    goal: str = Form(...),
    intensity: str = Form(...),
    db: Session = Depends(get_db),
):
    try:
        data = UserInput(username=username, user_id=user_id, age=age, weight=weight, goal=goal, intensity=intensity)
        user = save_user(db, data)
        workout_plan = generate_workout_gemini(user)
        tip = generate_nutrition_tip_with_flash(user.goal, user.age)
        plan = save_plan(db, user, workout_plan, tip)
        return templates.TemplateResponse("result.html", {
            "request": request, "user": user, "plan": plan,
            "plan_data": plan_for_template(workout_plan), "nutrition_tip": tip,
            "message": "Your 7-day plan has been generated."
        })
    except Exception as exc:
        return templates.TemplateResponse("index.html", {
            "request": request, "error": str(exc)
        }, status_code=400)

@router.post("/submit-feedback", response_class=HTMLResponse)
def submit_feedback(
    request: Request,
    user_id: str = Form(...),
    feedback: str = Form(...),
    db: Session = Depends(get_db),
):
    user = get_user(db, user_id.strip())
    if not user:
        return templates.TemplateResponse("index.html", {
            "request": request, "error": "User ID was not found."
        }, status_code=404)
    if not feedback.strip() or len(feedback.strip()) > 2000:
        return templates.TemplateResponse("index.html", {
            "request": request, "error": "Feedback must be between 1 and 2000 characters."
        }, status_code=400)
    plan = get_latest_plan(db, user)
    if not plan:
        raise HTTPException(status_code=404, detail="No workout plan exists for this user.")
    try:
        updated = update_workout_plan(plan.original_plan, feedback.strip(), user)
        update_plan(db, plan, updated, feedback.strip())
        return templates.TemplateResponse("result.html", {
            "request": request, "user": user, "plan": plan,
            "plan_data": plan_for_template(updated),
            "nutrition_tip": plan.nutrition_tip,
            "message": "Your plan was updated using your feedback."
        })
    except Exception as exc:
        return templates.TemplateResponse("result.html", {
            "request": request, "user": user, "plan": plan,
            "plan_data": plan_for_template(plan.updated_plan or plan.original_plan),
            "nutrition_tip": plan.nutrition_tip,
            "error": str(exc)
        }, status_code=400)

@router.get("/view-all-users", response_class=HTMLResponse)
def view_all_users(request: Request, password: str = "", db: Session = Depends(get_db)):
    settings = get_settings()
    if password != settings.admin_password:
        return templates.TemplateResponse("admin_login.html", {"request": request, "error": "Invalid admin password."}, status_code=401)
    users = get_all_users(db)
    return templates.TemplateResponse("all_users.html", {"request": request, "users": users, "password": password})

@router.post("/delete-user")
def delete_user_route(user_id: int = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
    if password != get_settings().admin_password:
        raise HTTPException(status_code=401, detail="Invalid admin password.")
    user = db.get(__import__("app.database", fromlist=["User"]).User, user_id)
    if user:
        delete_user(db, user)
    return RedirectResponse(url=f"/view-all-users?password={password}", status_code=303)
