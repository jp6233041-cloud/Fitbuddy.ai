from google import genai
from google.genai import types
from .config import get_settings

settings = get_settings()

def generate_nutrition_tip_with_flash(goal: str, age: int) -> str:
    if not settings.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY is not configured.")
    client = genai.Client(api_key=settings.gemini_api_key)
    prompt = f"""
Give one concise, practical nutrition or recovery tip for a person age {age}
whose wellness goal is {goal}. Keep it supportive and evidence-aware.
Do not prescribe calorie limits, fasting, supplements, or restrictive diets.
For minors, emphasize regular balanced meals, hydration, sleep, and involving
a parent/guardian or qualified professional for individualized nutrition advice.
Return plain text in 2-4 sentences.
"""
    response = client.models.generate_content(
        model=settings.gemini_tip_model,
        contents=prompt,
        config=types.GenerateContentConfig(temperature=0.4, max_output_tokens=300),
    )
    return (response.text or "").strip()
