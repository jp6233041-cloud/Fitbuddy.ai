import os
os.environ["GEMINI_API_KEY"] = "test-key"
os.environ["ADMIN_PASSWORD"] = "test-admin"

from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_home():
    response = client.get("/")
    assert response.status_code == 200
    assert "FitBuddy" in response.text

def test_admin_requires_password():
    response = client.get("/view-all-users")
    assert response.status_code == 401
    assert "Invalid admin password" in response.text
